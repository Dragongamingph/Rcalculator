package com.rafael.calculator;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.content.*;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainCalcuActivity extends Activity {

	// LIST OF IDS

	Button btn0, btn1, btn2, btn3, btn4, btn5, btn6,
	btn7, btn8, btn9, btnadd, btnsub, btndiv,
	btnmul, btnc, btnequal;
    EditText edittext1;

    float mValueOne, mValueTwo;

	// Boolean list

    boolean Addition, Subtract, Multiply, Division;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calcu);


		// setup Btn ids here!!

		btn0 = (Button) findViewById(R.id.btn0);
		btn1 = (Button) findViewById(R.id.btn1);
		btn2 = (Button) findViewById(R.id.btn2);
		btn3 = (Button) findViewById(R.id.btn3);
		btn4 = (Button) findViewById(R.id.btn4);
		btn5 = (Button) findViewById(R.id.btn5);
		btn6 = (Button) findViewById(R.id.btn6);
		btn7 = (Button) findViewById(R.id.btn7);
		btn8 = (Button) findViewById(R.id.btn8);
		btn9 = (Button) findViewById(R.id.btn9);
		btnadd = (Button) findViewById(R.id.btnadd);
		btnsub = (Button) findViewById(R.id.btnsub);
		btnmul = (Button) findViewById(R.id.btnmul);
		btndiv = (Button) findViewById(R.id.btndiv);
		btnequal = (Button) findViewById(R.id.btnequals);
		btnc = (Button) findViewById(R.id.btnc);
		edittext1 = (EditText) findViewById(R.id.edittext1);

		// BUTTON ONCLICK LISTENER STARTS HERE.

		btn1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					edittext1.setText(edittext1.getText() + "1");
				}
			});


		btn2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					edittext1.setText(edittext1.getText() + "2");
				}
			});

		btn3.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					edittext1.setText(edittext1.getText() + "3");
				}
			});

		btn4.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					edittext1.setText(edittext1.getText() + "4");
				}
			});

		btn5.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					edittext1.setText(edittext1.getText() + "5");
				}
			});

	    btn6.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					edittext1.setText(edittext1.getText() + "6");
				}
			});


		btn7.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					edittext1.setText(edittext1.getText() + "7");
				}
			});

		btn8.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					edittext1.setText(edittext1.getText() + "8");
				}
			});

		btn9.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					edittext1.setText(edittext1.getText() + "9");
				}
			});

		btn0.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					edittext1.setText(edittext1.getText() + "0");
				}
			});

		btnadd.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {

					if (edittext1 == null){
						edittext1.setText("");
					}
					else{
						mValueOne = Float.parseFloat(edittext1.getText()+ "");
						Addition = true;
						edittext1.setText("");
					}
				}
			});

		btnsub.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {

					if (edittext1 == null){
						edittext1.setText("");
					}
					else{
						mValueOne = Float.parseFloat(edittext1.getText()+ "");
					    Subtract = true;
						edittext1.setText(null);
					}
				}
			});

		btnmul.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {

					if (edittext1 == null){
						edittext1.setText("");
					}
					else{
						mValueOne = Float.parseFloat(edittext1.getText()+ "");
					    Multiply = true;
						edittext1.setText(null);
					}
				}
			});

		btndiv.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {

					if (edittext1 == null){
						edittext1.setText("");
					}
					else{
						mValueOne = Float.parseFloat(edittext1.getText()+ "");
					    Division = true;
						edittext1.setText(null);
					}
				}
			});

		btnequal.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {

					mValueTwo = Float.parseFloat(edittext1.getText()+ "");

					if (Addition == true){
						edittext1.setText(mValueOne + mValueTwo + "");
						Addition = false;
					}
					if (Subtract == true){
						edittext1.setText(mValueOne - mValueTwo + "");
						Subtract = false;
					}
					if (Multiply == true){
						edittext1.setText(mValueOne * mValueTwo + "");
						Multiply = false;
					}
					if (Division == true){
						edittext1.setText(mValueOne / mValueTwo + "");
						Division = false;
					}


				}
	 		});
		btnc.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {

					edittext1.setText("");
				}
			});	

		Toast.makeText(this, "Welcome to R_Calculator", Toast.LENGTH_SHORT).show();}



}
