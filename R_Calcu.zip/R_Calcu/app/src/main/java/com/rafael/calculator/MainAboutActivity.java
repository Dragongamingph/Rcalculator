package com.rafael.calculator;

import android.app.*;
import android.os.*;

public class MainAboutActivity extends Activity
{
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);

        setContentView(R.layout.about);
    }
}
