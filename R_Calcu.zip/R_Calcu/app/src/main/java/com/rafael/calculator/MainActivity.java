package com.rafael.calculator;

import android.app.*;
import android.os.*;
import android.content.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);}
	
	public void calcuBtn(View view) 
    {
    	Intent intent = new Intent(this, MainCalcuActivity.class);
    	startActivity(intent);
		}
    public void aboutBtn(View view) 
    {
    	Intent intent = new Intent(this, MainAboutActivity.class);
    	startActivity(intent);
		Toast.makeText(this, "About App", Toast.LENGTH_SHORT).show();}

	public void exitBtn(View view)
	{
		
		Toast.makeText(this, "App Closed!", Toast.LENGTH_SHORT).show();
		finish();
	
		}
	
	
}
